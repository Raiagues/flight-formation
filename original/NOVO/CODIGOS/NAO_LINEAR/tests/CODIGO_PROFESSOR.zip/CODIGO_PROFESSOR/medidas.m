clc
clear all

global mu
format long
r = 10*sqrt(2); 
passo = 5; 
T = 4*5752;
h = T/passo;
mu = 3.986004418e14;
Earth_r = 6378140;
a0 = Earth_r + 600e3; 
n0 = sqrt(mu/a0^3);
e0 = 0.1;
omega0 = 0;
f0 = 0;
theta = omega0 + f0;
num_orbits = 4;

%% Condições iniciais
xn = -0.01127;
yn = 0;
zn = 0.1;
xdot_n = 0.02;
ydot_n = 0.02;
zdot_n = 0;
r0 = (a0*(1-e0^2))/(1+e0*cos(f0));
r0dot = e0*sin(f0)*sqrt(mu/(a0*(1-e0^2)));
thetadot = (sqrt(mu/(a0*(1-e0^2))^3))*(1+e0*cos(f0))^2;

%Valores iniciais para vetor de estados
x1o = xn*a0;            % x         [m]
x2o = yn*a0;            % y         [m]
x3o = zn*a0;            % z         [m]
x4o = xdot_n*(n0*a0);   % xdot      [m/s]
x5o = ydot_n*(n0*a0);   % ydot      [m/s]
x6o = zdot_n*(n0*a0);   % zdot      [m/s]
x7o = r0;               % r0        [m]
x8o = r0dot;            % r0dot     [m]
x9o = theta;            % theta0    [rad]
x10o = thetadot;        % theta0dot [rad/s]

%Valores iniciais para matriz de covariancia
p1o = 15;               % [m]
p2o = 15;               % [m]
p3o = 15;               % [m]
p4o = 0.1;              % [m/s]
p5o = 0.1;              % [m/s]
p6o = 0.1;              % [m/s]
p7o = 1.5e-1;           % [m]
p8o = 1e-10;            % [m/s]
p9o = 1e-10*pi/180;     % [rad]
p10o = 0.001*pi/180;    %[rad/s]   

Xo = [x1o; x2o; x3o; x4o; x5o; x6o; x7o; x8o; x9o; x10o];
Po = diag([p1o^2; p2o^2; p3o^2; p4o^2; p5o^2; p6o^2; p7o^2; p8o^2; p9o^2; p10o^2]);

Xc = Xo;
Pc = Po;

CI = [Xc; Pc(:,1); Pc(:,2); Pc(:,3); Pc(:,4); Pc(:,5); Pc(:,6); Pc(:,7); Pc(:,8); Pc(:,9); Pc(:,10)];

tab1 = zeros(floor(h),111);

% for i = 1:h(1),
for i = 1:h,
    %Fase Propagação
    [t,Xp] = ode45(@edo,[(passo*i-passo) i*passo],CI);
    CI = Xp(end,:);
    tab1(i,:) = [i*passo CI];
    
end

Xp = tab1;
S = Xp(:,2:4);
d = size(Xp);
R = (r*randn(d(1),3));

data = [Xp(:,1) (S+R)];
data_verdade = [Xp(:,1) (Xp(:,2:11))];
dados_hiperdim = [Xp(:,1) (S+R*5e2)];

save data.dat data -ascii
save data_verdade.dat data_verdade -ascii
save dados_hiperdim.dat dados_hiperdim -ascii


xyz = data_verdade(:,2:4);

dados_hiperdim2 = S+R*5e2;

figure(1)
subplot(2,2,1)
plot(dados_hiperdim2(:,1)/a0,dados_hiperdim2(:,2)/a0)
hold on
plot(xyz(:,1)/a0,xyz(:,2)/a0)
hold off
xlabel('x (m)');
ylabel('y (m)');
xlim([-0.06 0.06]);
ylim([-0.08 0.08]);
legend('Órbita Sem Ruídos','Órbita Com Ruídos','Location','NorthWest');
grid on
subplot(2,2,2)
plot(dados_hiperdim2(:,1)/a0,dados_hiperdim2(:,3)/a0)
hold on
plot(xyz(:,1)/a0,xyz(:,3)/a0)
hold off
xlabel('x (m)');
ylabel('z (m)');
xlim([-0.12 0.12]);
ylim([-0.14 0.14]);
grid on
subplot(2,2,3)
plot(dados_hiperdim2(:,2)/a0,dados_hiperdim2(:,3)/a0)
hold on
plot(xyz(:,2)/a0,xyz(:,3)/a0)
hold off
ylabel('z (m)');
xlim([-0.12 0.12]);
ylim([-0.14 0.14]);
grid on
subplot(2,2,4)
plot3(dados_hiperdim2(:,1)/a0,dados_hiperdim2(:,2)/a0,dados_hiperdim2(:,3)/a0)
hold on
plot3(xyz(:,1)/a0,xyz(:,2)/a0,xyz(:,3)/a0)
xlabel('x (m)');
ylabel('y (m)');
zlabel('z (m)');
xlim([-0.12 0.12]);
ylim([-0.12 0.12]);
zlim([-0.12 0.12]);
hold on
plot3(xyz(1,1)/a0,xyz(1,2)/a0,xyz(1,3)/a0,'*r')
hold off
grid on
